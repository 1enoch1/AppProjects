package com.example.enoch.AimFit.db;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

/**
 * Created by Rashid on 21/03/2018.
 */

public class DatabaseViewModel extends AndroidViewModel {

    private DbRepository dbRepository;
    private LiveData<List<DataSteps>> data;



    public DatabaseViewModel(@NonNull Application application) {
        super(application);

        dbRepository = new DbRepository(application);
        data = dbRepository.getData();
    }
    public LiveData<List<DataSteps>> getData(){
        return data;
    }

    public void Insert(DataSteps dataSteps){dbRepository.insert(dataSteps);
    }
}
