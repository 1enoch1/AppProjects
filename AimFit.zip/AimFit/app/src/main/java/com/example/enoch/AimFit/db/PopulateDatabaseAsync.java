package com.example.enoch.AimFit.db;

import android.os.AsyncTask;

/**
 * Created by Rashid on 20/03/2018.
 */

public class PopulateDatabaseAsync extends AsyncTask<Void,Void,Void> {

    private final DatabaseDAO databaseDAO;

    public PopulateDatabaseAsync(DbRoomDatabase db) {
        databaseDAO = db.databaseDAO();
    }

    @Override
    protected Void doInBackground(Void... voids) {
        //test data
        databaseDAO.delete();
        System.out.println("POPULATE");
        DataSteps dataSteps = new DataSteps("200");
        databaseDAO.insert(dataSteps);

        return null;
    }
}
