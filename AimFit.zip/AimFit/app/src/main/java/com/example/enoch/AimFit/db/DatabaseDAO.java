package com.example.enoch.AimFit.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

/**
 * Created by Rashid on 20/03/2018.
 */
@Dao
public interface DatabaseDAO {

    @Insert
    void insert(DataSteps data);

    @Query("DELETE FROM step_holder")
    void delete();



    @Query("SELECT * FROM step_holder")
    LiveData<List<DataSteps>> getData();


}
