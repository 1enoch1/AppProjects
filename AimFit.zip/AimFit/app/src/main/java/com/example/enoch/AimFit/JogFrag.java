package com.example.enoch.AimFit;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;


/**
 * A simple {@link Fragment} subclass.
 */
public class JogFrag extends Fragment {


    public JogFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_jog, container, false);
    }

    public void onViewCreated(View view, @Nullable Bundle SavedInstanceState) {

        ImageView imageView = getView().findViewById(R.id.runimage);
        Glide.with(getContext()).load(getImage("runimage")).into(imageView);

        ImageView imageView2 = getView().findViewById(R.id.distancecov);
        Glide.with(getContext()).load(getImage("distancecov")).into(imageView2);
        ImageView imageView3 = getView().findViewById(R.id.calsicon);
        Glide.with(getContext()).load(getImage("calsicon")).into(imageView3);


    }
    public int getImage(String string){

        int drawresourceid = this.getResources().getIdentifier(string, "drawable",getContext().getPackageName());

        return drawresourceid;
    }

}
