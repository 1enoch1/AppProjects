package com.example.enoch.AimFit;

/**
 * Created by rashid on 22/03/2018.
 */

public interface AsyncResponse {
        void processFinish(Integer output);
    }

