package com.example.enoch.AimFit;

import android.app.Activity;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.service.autofill.Dataset;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.enoch.AimFit.db.DataSteps;
import com.example.enoch.AimFit.db.DatabaseDAO;
import com.example.enoch.AimFit.db.DatabaseViewModel;
import com.example.enoch.AimFit.db.DbRoomDatabase;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessOptions;
import com.google.android.gms.fitness.data.DataPoint;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.DataSource;
import com.google.android.gms.fitness.data.DataType;
import com.google.android.gms.fitness.data.Field;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.result.DailyTotalResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.text.DateFormat;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class HomeFragment extends Fragment implements
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,
        AsyncResponse {

    AsyncResponse del;
    DatabaseDAO databaseDAO;
    List<DataSteps> steps;
    LiveData<List<DataSteps>> dbList;

    TextView welcomeText;

    DatabaseViewModel model;

    int REQUEST_OAUTH_REQUEST_CODE;

    GoogleApiClient mGoogleApiClient;

    GoogleSignInAccount account;

    ImageView userImage;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        DbRoomDatabase dbRoomDatabase = DbRoomDatabase.getDatabase(getContext());
        databaseDAO = dbRoomDatabase.databaseDAO();
        dbList = databaseDAO.getData();


        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        //+steps = (List<DataSteps>)dbList;

        model = ViewModelProviders.of(this).get(DatabaseViewModel.class);


        dbList.observe(this, new Observer<List<DataSteps>>() {
            @Override
            public void onChanged(@Nullable List<DataSteps> databases) {
                steps = databases;
            }
        });

        FitnessOptions fitnessOptions =
                FitnessOptions.builder()
                        .addDataType(DataType.TYPE_STEP_COUNT_CUMULATIVE)
                        .addDataType(DataType.TYPE_STEP_COUNT_DELTA)
                        .build();


        if (!GoogleSignIn.hasPermissions(GoogleSignIn.getLastSignedInAccount(getContext()), fitnessOptions)) {
            GoogleSignIn.requestPermissions(
                    this,
                    REQUEST_OAUTH_REQUEST_CODE,
                    GoogleSignIn.getLastSignedInAccount(getContext()),
                    fitnessOptions);
        } else {
            subscribe();
        }




        return rootView;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_OAUTH_REQUEST_CODE) {

                subscribe();
            }
        }
    }

    public void onStart() {
        super.onStart();
        account = GoogleSignIn.getLastSignedInAccount(getContext());
        updateUI(account);
    }

    public void updateUI(GoogleSignInAccount account){

        if (account == null){
            Toast.makeText(getContext(), "PLEASE LOG IN",Toast.LENGTH_LONG ).show();
        }

        else{
            Toast.makeText(getContext(), "Logged in as " + account.getDisplayName(), Toast.LENGTH_LONG).show();
            welcomeText = (TextView)getView().findViewById(R.id.welcomeText);
            welcomeText.setText("Welcome Back "+ account.getDisplayName());
            userImage = (ImageView)getView().findViewById(R.id.profile);
            Glide.with(getContext()).load(account.getPhotoUrl()).into(userImage);

        }

    }
    public void subscribe() {
        // To create a subscription, invoke the Recording API. As soon as the subscription is
        // active, fitness data will start recording.
        Fitness.getRecordingClient(getContext(), GoogleSignIn.getLastSignedInAccount(getContext()))
                .subscribe(DataType.TYPE_STEP_COUNT_CUMULATIVE)
                .addOnCompleteListener(
                        new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Log.i("HI", "Successfully subscribed!");
                                    System.out.println("I SUBSCRIBE 2");
                                } else {
                                    Log.w("HI", "There was a problem subscribing.", task.getException());
                                }
                            }
                        });
    }

    private void readData() {
        Fitness.getHistoryClient(getContext(), GoogleSignIn.getLastSignedInAccount(getContext()))
                .readDailyTotal(DataType.TYPE_STEP_COUNT_DELTA)
                .addOnSuccessListener(
                        new OnSuccessListener<DataSet>() {
                            @Override
                            public void onSuccess(DataSet dataSet) {
                                long total =
                                        dataSet.isEmpty()
                                                ? 0
                                                : dataSet.getDataPoints().get(0).getValue(Field.FIELD_STEPS).asInt();
                                Log.i("HI", "Total steps: " + total);
                            }
                        })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("HI", "There was a problem getting the step count.", e);
                            }
                        });
    }


    public void onViewCreated(View view, @Nullable Bundle SavedInstanceState) {


        mGoogleApiClient = new GoogleApiClient.Builder(getContext())
                .addApi(Fitness.HISTORY_API)
                .addScope(new Scope(Scopes.FITNESS_ACTIVITY_READ_WRITE))
                .addConnectionCallbacks(this)
                .enableAutoManage(getActivity(), 0, this)
                .build();



        ImageView imageView = getView().findViewById(R.id.homeimage);
        Glide.with(getContext()).load(getImage("stayfit")).into(imageView);
        final TextView steps = (TextView) getView().findViewById(R.id.stepsday);


        del = new AsyncResponse() {
            @Override
            public void processFinish(Integer output) {
                steps.setText(String.valueOf(output));

            }
        };
        ViewWeekStepCountTask asyncTask =new ViewWeekStepCountTask(del);
        asyncTask.execute();

    }

    public void returnDate() {
        //int length = steps.size();


    }


    public int getImage(String string) {

        int drawresourceid = this.getResources().getIdentifier(string, "drawable", getContext().getPackageName());

        return drawresourceid;
    }


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.e("HistoryAPI", "onConnected");
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void processFinish(Integer output) {

        System.out.println("OUT" + output);

    }

    private class ViewWeekStepCountTask extends AsyncTask<Object, Object, Integer> {

        private AsyncResponse del;
        private Context mContext;




        public ViewWeekStepCountTask(AsyncResponse delegate){
            this.del = delegate;

        }
        @Override
        protected Integer doInBackground(Object... objects) {

            String result = "hello";
            int val =displayStepDataForToday();
            return val;
        }


        @Override
        protected void onPostExecute(Integer v){
            int a = v;
            del.processFinish(a);

        }

        private int displayStepDataForToday() {
            DailyTotalResult result = Fitness.HistoryApi.readDailyTotal(mGoogleApiClient, DataType.TYPE_STEP_COUNT_DELTA).await(1, TimeUnit.MINUTES);
            DataSet res = result.getTotal();
            int steps = 0;
            for (DataPoint dp : res.getDataPoints()) {
                for (Field field : res.getDataType().getFields()) {
                    steps = (dp.getValue(field)).asInt();
                }
            }


            showDataSet(res);

            return steps;


        }

        private void showDataSet(DataSet dataSet) {
            Log.e("History", "Data returned for Data type: " + dataSet.getDataType().getName());
            DateFormat dateFormat = DateFormat.getDateInstance();
            DateFormat timeFormat = DateFormat.getTimeInstance();

            for (DataPoint dp : dataSet.getDataPoints()) {
                Log.e("History", "Data point:");
                Log.e("History", "\tType: " + dp.getDataType().getName());
                Log.e("History", "\tStart: " + dateFormat.format(dp.getStartTime(TimeUnit.MILLISECONDS)) + " " + timeFormat.format(dp.getStartTime(TimeUnit.MILLISECONDS)));
                Log.e("History", "\tEnd: " + dateFormat.format(dp.getEndTime(TimeUnit.MILLISECONDS)) + " " + timeFormat.format(dp.getStartTime(TimeUnit.MILLISECONDS)));
                for (Field field : dp.getDataType().getFields()) {
                    Log.e("History", "\tField: " + field.getName() +
                            " Value: " + dp.getValue(field));
                }
            }
        }


    }


}
