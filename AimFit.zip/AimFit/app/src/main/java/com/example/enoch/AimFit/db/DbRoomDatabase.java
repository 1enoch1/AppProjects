package com.example.enoch.AimFit.db;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.*;
import android.content.Context;
import android.support.annotation.NonNull;
import android.arch.persistence.room.Database;

/**
 * Created by Rashid on 20/03/2018.
 */
@Database(entities = {DataSteps.class}, version = 1)
public abstract class DbRoomDatabase extends RoomDatabase {

    public abstract DatabaseDAO databaseDAO();

    private static DbRoomDatabase INSTANCE;

    public static DbRoomDatabase getDatabase(final Context context) {

        System.out.println("I GOT HERE");

        if (INSTANCE == null) {

            synchronized (DbRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            DbRoomDatabase.class, "step_database").addCallback(sDBcallback)
                            .build();

                    System.out.println("HII");
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sDBcallback =
            new RoomDatabase.Callback() {
                @Override
                public void onOpen(@NonNull SupportSQLiteDatabase db) {
                    super.onOpen(db);
                    System.out.println("CALLBACK");
                    new PopulateDatabaseAsync(INSTANCE).execute();
                }
            };
}

