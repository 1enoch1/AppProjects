package com.example.enoch.AimFit;


import android.app.AlarmManager;
import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.util.logging.Logger;

public class SensorSet extends Service implements SensorEventListener{
    private final static int NOTIFIER_ID = 1;
    private final static long MICROSECONDS_TO_MINS = 60000000;
    private final static long SAVE_OFFTIME = AlarmManager.INTERVAL_HOUR;
    private final static int SAVE_OFFSTEPS = 500;

    public final static String PAUSE_MODE = "pause";

    private static int yourSteps;
    private static int prevSteps;
    private static long prevTime;

    public final static String MODE_UPDATE_NOTIFICATION = "updateNotificationState";
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(BuildConfig.DEBUG) Logger.getLogger("This is not a real value: " + event.values[0]);




    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}