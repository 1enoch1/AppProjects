package com.example.enoch.AimFit.db;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

/**
 * Created by Rashid on 21/03/2018.
 */

public class DbRepository {

    private DatabaseDAO databaseDAO;
    private LiveData<List<DataSteps>> data;

    DbRepository(Application application){
        DbRoomDatabase db = DbRoomDatabase.getDatabase(application);
        databaseDAO = db.databaseDAO();
        data = databaseDAO.getData();
    }

    LiveData<List<DataSteps>> getData(){return data;}

    public void insert(DataSteps dataSteps){new insertAsyncTask(databaseDAO).execute(dataSteps);}

    private static class insertAsyncTask extends AsyncTask<DataSteps, Void, Void>{
        private DatabaseDAO databaseDAO;

        insertAsyncTask(DatabaseDAO dao) {
            databaseDAO = dao;
        }

        @Override
        protected Void doInBackground(final DataSteps... params) {

            databaseDAO.insert(params[0]);

            return null;
        }
    }
}
