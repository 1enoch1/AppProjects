package com.example.enoch.AimFit.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

/**
 * Created by Rashid on 20/03/2018.
 */
@Entity(tableName = "step_holder")
public class DataSteps {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;


    @ColumnInfo (name = "date")
    private String date;

    @ColumnInfo (name = "distance")
    private String distance;

    @ColumnInfo (name = "dist2")
    private String dist;

    public DataSteps( String date){

        this.date = date;

    }


    public void setDist(String dist){
        this.dist = dist;
    }

    public String getDate(){
        return this.date;
    }

    public String getDistance(){
        return this.distance;
    }

    public String getDist(){
        return this.dist ;
    }

    public void setDate(String date){
        this.date = date;
    }

    public void setDistance(String distance){
        this.distance = distance;
    }

    public int getId(){
        return this.id;
    }

    public void setId(int id){

        this.id = id;

    }






    // values sent to a database
}
