package com.example.enoch.AimFit;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.widget.TextView;


import java.text.NumberFormat;
import java.util.Locale;


/**
 * A simple {@link /Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link /WalkFrag.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link //WalkFrag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WalkFrag extends Fragment implements SensorEventListener{
    private TextView takenSteps, showTotal, showAvg, textView;

    public int todayOff, startTotal, stepGoal, dayTotal;
    public final static NumberFormat showFormat = NumberFormat.getInstance(Locale.getDefault());
    private boolean steps = true;

    //Button btnStart;
    //Button btnStop;
    //private StepCount counterStep;
    //private SensorManager senseM;
    //private static final String TEXT_NUM_STEPS = "NUMBER OF STEPS: ";
    //private int numSteps;


    public WalkFrag() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_walk, container, Boolean.parseBoolean(null));


        return view;
    }

    public void onViewCreated(View view, @Nullable Bundle SavedInstanceState) {

        /*ImageView imageView = (ImageView)getView().findViewById(R.id.walkimage);
        Glide.with(getContext()).load(getImage("walkimage")).into(imageView);*/
        /*ImageView imageView2 = (ImageView) getView().findViewById(R.id.stepcount1);
        Glide.with(getContext()).load(getImage("stepcount")).into(imageView2);
        */
        /*steps = (TextView) getView().findViewById(R.id.showsteps);
        * gfSteps = (TextView) getView().findViewById(R.id.showsteps);*/
        //steps = (TextView) view.findViewById(R.id.steps_taken);
        Button btnStart = getView().findViewById(R.id.btn_startcounter);
        Button btnStop = getView().findViewById(R.id.btn_stopcounter);


// calls a basic step counter
        //counterStep = new StepCount();
        //counterStep.registerListener(this);
    }



/*
        btnStart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                numSteps = 0;
                senseM.registerListener(WalkFrag.this, accel, SensorManager.SENSOR_DELAY_FASTEST);

            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                senseM.unregisterListener(WalkFrag.this);

            }
        });


    }
*//*
    private SensorManager getSystemService(String sensorService) {
        return senseM;
    }
*/
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            //counterStep.updateAccel(
             //       event.timestamp, event.values[0], event.values[1], event.values[2]);
        }
    }
/*
    @Override
    public void step(long timedNS) {
        numSteps++;
        // change this to show Googlefit step counter
        steps.setText(TEXT_NUM_STEPS + numSteps);
    }

*/

    public int getImage(String string){

        int drawresourceid = this.getResources().getIdentifier(string, "drawable",getContext().getPackageName());

        return drawresourceid;
    }
}
